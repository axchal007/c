﻿
public partial class Employee
{
    public double CalculateSalary()
    {
   
        return BaseSalary;
    }
}
