﻿// EmployeeProperties.cs
public partial class Employee
{
    public string EmployeeId { get; set; }
    public string Department { get; set; }
    public double BaseSalary { get; set; }
}
