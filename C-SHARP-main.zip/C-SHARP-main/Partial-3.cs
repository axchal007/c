﻿//PersonMethods.cs
using System;

public partial class Person
{
    public void PrintFullName()
    {
        Console.WriteLine($"{FirstName} {LastName}");
    }
}
